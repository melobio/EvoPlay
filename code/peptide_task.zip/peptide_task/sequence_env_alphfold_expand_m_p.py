# -*- coding: utf-8 -*-

from __future__ import print_function
import numpy as np
import torch
import random
from typing import List, Union, Dict, Optional
import copy
import pandas as pd
import os
import pickle
import sys
import time
import re
import math

from absl import logging

from alphafold.common import protein
from alphafold.common import residue_constants
from alphafold.data import msaonly
from alphafold.data import foldonly
from alphafold.data import pipeline
from alphafold.data import templates
from alphafold.model import data
from alphafold.model import config
from alphafold.model import model

import jax
from jax import numpy as jnp
from jax import grad, value_and_grad
import copy
from collections import defaultdict
from Bio.SVDSuperimposer import SVDSuperimposer
#from src.mutate_sequence import mutate_sequence
import pdb

def mutate_sequence(peptide_sequence, ex_list):
    '''Mutate the amino acid sequence randomly
    '''

    restypes = np.array(['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I',
                         'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V' ])
    seqlen = len(peptide_sequence)
    #searched_seqs = sequence_scores['sequence']
    #Mutate seq
    seeds = peptide_sequence
    #Go through a shuffled version of the positions and aas
    while True:
        seeds = peptide_sequence
        pi_s = np.random.choice(np.arange(seqlen), 3, replace=False) # True,mutate<=3, False=3
        for pi in pi_s:
            aa = np.random.choice(restypes, replace=False)
            #new_s
            new_seq = seeds[:pi] + aa + seeds[pi + 1:]
            seeds = new_seq
        if new_seq not in ex_list:
            break
    return new_seq

# ### NVIDIA Setting
# cmd = "nvidia-smi -q -d Memory |grep -A4 GPU|grep Free"
# print('cmd: ', cmd)
# process = os.popen(cmd)  # return file
# output = process.read()
# print(output)
# process.close()
# memory_gpu = [int(x.split()[2]) for x in output.strip().split('\n')]
# print([str(ii) + ':' + str(v) for ii, v in enumerate(memory_gpu)])
# print('max remain memory GPU:', str(np.argmax(memory_gpu)))
# set gpu env
os.environ['CUDA_VISIBLE_DEVICES'] = '0' # str(np.argmax(memory_gpu))
# set JAX gpu  memory
# os.environ['TF_FORCE_UNIFIED_MEMORY'] = '1'
# os.environ['XLA_PYTHON_CLIENT_MEM_FRACTION'] = '.50'

#####alphafold setting

#####alphafold function
#####alphafold function
def update_features(feature_dict, peptide_sequence):
    '''Update the features used for the pred:
    #Sequence features
    'aatype', 'between_segment_residues', 'domain_name',
    'residue_index', 'seq_length', 'sequence',
    #MSA features
    'deletion_matrix_int', 'msa', 'num_alignments',
    #Template features
    'template_aatype', 'template_all_atom_masks',
    'template_all_atom_positions', 'template_domain_names',
    'template_sequence', 'template_sum_probs'
    '''
    #Save
    new_feature_dict = {}

    peptide_features = pipeline.make_sequence_features(sequence=peptide_sequence,
                                                    description='peptide', num_res=len(peptide_sequence))
    #Merge sequence features
    #aatype
    new_feature_dict['aatype']=np.concatenate((feature_dict['aatype'],peptide_features['aatype']))
    #between_segment_residues
    new_feature_dict['between_segment_residues']=np.concatenate((feature_dict['between_segment_residues'],peptide_features['between_segment_residues']))
    #domain_name
    new_feature_dict['domain_name'] = feature_dict['domain_name']
    #residue_index
    new_feature_dict['residue_index']=np.concatenate((feature_dict['residue_index'],peptide_features['residue_index']+feature_dict['residue_index'][-1]+201))
    #seq_length
    new_feature_dict['seq_length']=np.concatenate((feature_dict['seq_length']+peptide_features['seq_length'][0],
                                            peptide_features['seq_length']+feature_dict['seq_length'][0]))
    #sequence
    new_feature_dict['sequence']=np.array(feature_dict['sequence'][0]+peptide_features['sequence'][0], dtype='object')

    #Merge MSA features
    #deletion_matrix_int
    new_feature_dict['deletion_matrix_int']=np.concatenate((feature_dict['deletion_matrix_int'],
                                            np.zeros((feature_dict['deletion_matrix_int'].shape[0],len(peptide_sequence)))), axis=1)
    #msa
    peptide_msa = np.zeros((feature_dict['deletion_matrix_int'].shape[0],len(peptide_sequence)),dtype='int32')
    peptide_msa[:,:] = 21
    HHBLITS_AA_TO_ID = {'A': 0,'B': 2,'C': 1,'D': 2,'E': 3,'F': 4,'G': 5,'H': 6,'I': 7,'J': 20,'K': 8,'L': 9,'M': 10,'N': 11,
                        'O': 20,'P': 12,'Q': 13,'R': 14,'S': 15,'T': 16,'U': 1,'V': 17,'W': 18,'X': 20,'Y': 19,'Z': 3,'-': 21,}
    for i in range(len(peptide_sequence)):
        peptide_msa[0,i]=HHBLITS_AA_TO_ID[peptide_sequence[i]]
    new_feature_dict['msa']=np.concatenate((feature_dict['msa'], peptide_msa), axis=1)
    #num_alignments
    new_feature_dict['num_alignments']=np.concatenate((feature_dict['num_alignments'], feature_dict['num_alignments'][:len(peptide_sequence)]))

    #Merge template features
    for key in ['template_aatype', 'template_all_atom_masks', 'template_all_atom_positions',
                'template_domain_names', 'template_sequence', 'template_sum_probs']:
        new_feature_dict[key]=feature_dict[key]

    return new_feature_dict

def predict_function(peptide_sequence, feature_dict, output_dir, model_runners,
                     random_seed, receptor_if_residues, receptor_CAs, peptide_CM):
    '''Predict and calculate loss
    '''


    #Add features for the binder
    #Update features
    new_feature_dict = update_features(feature_dict, peptide_sequence)
    # Write out features as a pickled dictionary.
    features_output_path = os.path.join(output_dir, 'features.pkl')
    with open(features_output_path, 'wb') as f:
      pickle.dump(new_feature_dict, f, protocol=4)
    # Run the model.
    for model_name, model_runner in model_runners.items():
      logging.info('Running model %s', model_name)
      processed_feature_dict = model_runner.process_features(
          new_feature_dict, random_seed=random_seed)

      t_0 = time.time()
      prediction_result = model_runner.predict(processed_feature_dict)
      print('Prediction took', time.time() - t_0,'s')

    #Calculate loss
    #Loss features
    # Get the pLDDT confidence metric.
    plddt = prediction_result['plddt']
    #Get the protein
    plddt_b_factors = np.repeat(plddt[:, None], residue_constants.atom_type_num, axis=-1)
    unrelaxed_protein = protein.from_prediction(features=processed_feature_dict,result=prediction_result,b_factors=plddt_b_factors)
    protein_resno, protein_atoms, protein_atom_coords = protein.get_coords(unrelaxed_protein)
    peptide_length = len(peptide_sequence)
    #Get residue index
    residue_index = new_feature_dict['residue_index']
    receptor_res_index = residue_index[:-peptide_length]
    peptide_res_index = residue_index[-peptide_length:]
    #Get coords
    receptor_coords = protein_atom_coords[np.argwhere(protein_resno<=receptor_res_index[-1]+1)[:,0]]
    peptide_coords = protein_atom_coords[np.argwhere(protein_resno>receptor_res_index[-1]+1)[:,0]]
    #Get atom types
    receptor_atoms = protein_atoms[np.argwhere(protein_resno<=receptor_res_index[-1]+1)[:,0]]
    peptide_atoms = protein_atoms[np.argwhere(protein_resno>receptor_res_index[-1]+1)[:,0]]
    #Get resno for each atom
    #Start at 1 - same for receptor_if_residues
    receptor_resno = protein_resno[np.argwhere(protein_resno<=receptor_res_index[-1]+1)[:,0]]
    peptide_resno = protein_resno[np.argwhere(protein_resno>peptide_res_index[0])[:,0]]
    #Get atoms belonging to if res for the receptor
    receptor_if_pos = []
    for ifr in receptor_if_residues:
        receptor_if_pos.extend([*np.argwhere(receptor_resno==ifr)])
    receptor_if_pos = np.array(receptor_if_pos)[:,0]

    #Calc 2-norm - distance between peptide and interface
    mat = np.append(peptide_coords,receptor_coords[receptor_if_pos],axis=0)
    a_min_b = mat[:,np.newaxis,:] -mat[np.newaxis,:,:]
    dists = np.sqrt(np.sum(a_min_b.T ** 2, axis=0)).T
    l1 = len(peptide_coords)
    #Get interface
    contact_dists = dists[:l1,l1:] #first dimension = peptide, second = receptor

    #Get the closest atom-atom distances across the receptor interface residues.
    closest_dists_peptide = contact_dists[np.arange(contact_dists.shape[0]),np.argmin(contact_dists,axis=1)]
    closest_dists_receptor = contact_dists[np.argmin(contact_dists,axis=0),np.arange(contact_dists.shape[1])]

    #Get the peptide plDDT
    peptide_plDDT = plddt[-peptide_length:]

    #Superpose the receptor CAs and compare the centre of mass
    sup = SVDSuperimposer()

    #Get the CAs for the receptor and peptide: order N, CA
    pred_receptor_CAs, pred_peptide_CAs = [], []
    for resno in np.unique(receptor_resno):
        pred_receptor_CAs.append(np.argwhere(receptor_resno==resno)[1][0])
    for resno in np.unique(peptide_resno):
        pred_peptide_CAs.append(np.argwhere(peptide_resno==resno)[1][0])
    #print('Checking SVDSuperimposer...')
    #print(receptor_CAs, receptor_coords[pred_receptor_CAs])
    sup.set(receptor_CAs, receptor_coords[pred_receptor_CAs]) #(reference_coords, coords)
    sup.run()
    rot, tran = sup.get_rotran()
    #Rotate the peptide coords to match the centre of mass for the native comparison
    rotated_coords = np.dot(peptide_coords[pred_peptide_CAs], rot) + tran
    rotated_CM =  np.sum(rotated_coords,axis=0)/(rotated_coords.shape[0])
    delta_CM = np.sqrt(np.sum(np.square(peptide_CM-rotated_CM)))

    return closest_dists_peptide.mean(), closest_dists_receptor.mean(), peptide_plDDT.mean(), delta_CM, unrelaxed_protein
#####alphafold function
#####alphafold function

##start_seqs

######move#######
#
#AAS = "ILVAGMFYWEDQNHCRKSTP"
AAS = "ARNDCQEGHILKMFPSTWYV"
def feature_single(variant):
    Feature = []
    aalist = list(AAS)
    for AA in variant:
        Feature.append([AA == aa for aa in aalist])
    Feature = np.asarray(Feature).astype(float)
    if len(Feature.shape) == 2:
        features = np.reshape(Feature, [Feature.shape[0] * Feature.shape[1]])

    return features
def string_to_one_hot(sequence: str, alphabet: str) -> np.ndarray:

    out = np.zeros((len(sequence), len(alphabet)))
    for i in range(len(sequence)):
        out[i, alphabet.index(sequence[i])] = 1
    return out

def one_hot_to_string(
    one_hot: Union[List[List[int]], np.ndarray], alphabet: str
) -> str:
    """
    Return the sequence string representing a one-hot vector according to an alphabet.

    """
    residue_idxs = np.argmax(one_hot, axis=1)
    return "".join([alphabet[idx] for idx in residue_idxs])

def map_to_full_len_gfp(start_seq, d_dict, truncated_str):
    wt_list = list(start_seq)
    for k, v in d_dict.items():
        wt_list[v] = truncated_str[k]
    gfp_mutate_seq = "".join(wt_list)
    return gfp_mutate_seq

def string_to_feature(string):
    seq_list = []
    seq_list.append(string)
    seq_np = np.array(
        [string_to_one_hot(seq, AAS) for seq in seq_list]
    )
    one_hots = torch.from_numpy(seq_np)
    one_hots = one_hots.to(torch.float32)
    return one_hots

# save unrelaxed pdb
def save_design(unrelaxed_protein, output_dir, model_name, l1):
    '''Save the resulting protein-peptide design to a pdb file
    '''

    unrelaxed_pdb_path = os.path.join(output_dir, f'unrelaxed_{model_name}.pdb')
    chain_name = 'A'
    with open(unrelaxed_pdb_path, 'w') as f:
        from alphafold.common import protein
        pdb_contents = protein.to_pdb(unrelaxed_protein).split('\n')
        for line in pdb_contents:
            try:
                record = parse_atm_record(line)
                if record['res_no'] > l1:
                    chain_name = 'B'
                outline = line[:21] + chain_name + line[22:]
                f.write(outline + '\n')
            except:
                f.write(line + '\n')

class Seq_env(object):
    """sequence space for the env"""
    def __init__(self,
                 seq_len,
                 alphabet,
                 #model,
                 pdbid,
                 starting_seq,
                 feature_output_dir,
                 recycle_num,
                 #combo_feature_map,
                 #first_round_index,
                 #combo_index_map,
                 #first_round_combo,
                 #feature_list,
                 trust_radus,
                 ):
        #self.max_moves = trust_radus
        self.move_count = 0
        self.seq_len = seq_len#self.width = int(kwargs.get('width', 8))
        self.vocab_size = len(alphabet)#self.height = int(kwargs.get('height', 8))
        #self.previous_fitness = -float("inf")
        self.alphabet = alphabet
        #self.model = model
        #
        self.starting_seq = starting_seq
        self.seq = starting_seq
        #self.start_seq_pool.remove(starting_seq)
        #self.init_combo
        #### modify by LiChao Yiwang
        ##alphafold_state
        aa = residue_constants.sequence_to_onehot(
        sequence=self.seq,
        mapping=residue_constants.restype_order_with_x,
        map_unknown_to_x=True)
        self.init_state = aa[:,0:-1]
        ##alphafold_state
        #self.previous_init_state = string_to_one_hot(self.seq, self.alphabet).astype(np.float32)
        self.previous_init_state = aa[:,0:-1]
        ##alphafold_state
        self.init_state_count = 0
        #self.previous_state = self.init_state
        #self.less_than_previous_count = []
        self.unuseful_move = 0
        self.states = {}

        #self.availables = list(range(self.seq_len * self.vocab_size))
        self.repeated_seq_ocurr = False
        #self.first_round_index = list(first_round_index)
        # self.combo_index_map = combo_index_map
        # self.index_combo_map = {v: k for k, v in self.combo_index_map.items()}
        # self.first_round_combo = [self.index_combo_map[ind] for ind in self.first_round_index]
        self.episode_seqs = []
        self.episode_seqs.append(starting_seq)
        ###debug
        ###debug
        #alphafold
        # self.removes = []
        # for i in range(0, len(starting_seq)):
        #     move = 21 * i + 20
        #     self.removes.append(move)
        self.loss = 0.0
        #self.alphfold_dict = {}
        #self.plddt = 0.0
        self.start_seq_exclude_list = []
        self.playout_dict = {}
        #self.current_seq = starting_seq
        # alphafold
        self.if_dist_peptide, self.if_dist_receptor = None, None
        self.plddt, self.delta_CM, self.unrelaxed_protein = None, None, None

        self.output_dir =feature_output_dir
        self.move_0_flag = False


        #####EvoZero setting

        IDS = "../../data/peptide_data/LNR_set_12sub.csv"  # "./data/LNR_set_12sub.csv"
        FASTADIR = "../../data/peptide_data/fasta/"
        RECEPTORDIR = "../../data/peptide_data/PDB/receptor/"
        PDBDIR = "../../data/peptide_data/PDB/"
        MSADIR = "../../data/peptide_data/MSA_dir/"
        IDS_df = pd.read_csv(IDS)
        PDBID = pdbid # '3vxw'  # PDBID = IDS_df["pdb_id"][idx] # "1ssc":0, "3r7g":7, "3vxw":8
        idx = IDS_df[IDS_df['pdb_id'] == PDBID].index[0]  # 8
        print(IDS_df.iloc[idx, :])
        RECEPTOR_CHAIN = IDS_df["receptor_chain"][idx]
        RECEPTORID = f"{PDBID}_{RECEPTOR_CHAIN}"
        print(f"RECEPTORID:\n{RECEPTORID}")

        RECEPTOR_SEQUENCE = f"{FASTADIR}/receptor/{RECEPTORID}.fasta"
        # RECEPTOR_SEQUENCE = open(RECEPTOR_SEQUENCE, 'r').readlines()[1].strip()
        print(f"RECEPTOR_SEQUENCE:\n{RECEPTOR_SEQUENCE}")

        ###Get receptor interface residues
        TARGET_RESIDUES = f"{RECEPTORDIR}/{RECEPTORID}_if.npy"
        TARGET_RESIDUES = list(np.load(TARGET_RESIDUES))
        print(f"TARGET_RESIDUES:\n{TARGET_RESIDUES}")

        BINDER_LENGTH = IDS_df["peptide_length"][idx]
        print(f"BINDER_LENGTH: {BINDER_LENGTH}")

        BINDER_COM = f'{PDBDIR}/{PDBID}_CM.npy'  # "33.966637,23.854908,9.859454"  # @param {type:"string"}
        BINDER_COM = list(np.load(BINDER_COM))
        print(f"BINDER_COM: {BINDER_COM}")

        # Receptor CAs
        RECEPTOR_CAs = f"{PDBDIR}/{PDBID}_receptor_CA.npy"
        RECEPTOR_CAs = np.load(RECEPTOR_CAs)
        print(f"RECEPTOR_CAs:\n{RECEPTOR_CAs[:5]}")

        # RECEPTOR_MSA
        RECEPTOR_MSA = f"{MSADIR}/{RECEPTORID}.a3m"  # RECEPTOR_MSA = 'data/test/1ssc_receptor.a3m' # 3388
        print(RECEPTOR_MSA)

        # Core
        self.receptor_CAs = RECEPTOR_CAs
        self.receptor_if_residues = TARGET_RESIDUES
        self.peptide_CM = BINDER_COM
        fasta_path = RECEPTOR_SEQUENCE  # OUTDIR + PDBID + '_receptor.fasta'

        # Check the MSA
        from check_msa_colab import process_a3m
        PROCESSED_MSA = RECEPTOR_MSA.split('.')[0] + '_processed.a3m'
        RECEPTOR_SEQUENCE = open(RECEPTOR_SEQUENCE, 'r').readlines()[1].strip()
        process_a3m(RECEPTOR_MSA, RECEPTOR_SEQUENCE, PROCESSED_MSA)  # remove insertions and get only matches and gaps
        RECEPTOR_MSA = PROCESSED_MSA
        msas = [RECEPTOR_MSA]

        #####alphafold setting
        data_pipeline = foldonly.FoldDataPipeline()
        print(fasta_path)
        self.feature_dict = data_pipeline.process(
            input_fasta_path=fasta_path,
            input_msas=msas,
            template_search=None,
            msa_output_dir=None)
        #####alphafold setting
        MODEL_NAME = 'model_1'
        model_names = [MODEL_NAME]
        num_ensemble = 1
        max_recycles = recycle_num   # 0 or 3 or 8
        alphafold_parameter_dir = "./AF"
        self.model_runners = {}
        for model_name in model_names:
            model_config = config.model_config(model_name)
            model_config.data.eval.num_ensemble = num_ensemble
            model_config.data.common.num_recycle = max_recycles
            model_config.model.num_recycle = max_recycles
            model_params = data.get_model_haiku_params(
                model_name=model_name, data_dir=alphafold_parameter_dir)
            model_runner = model.RunModel(model_config, model_params)
            self.model_runners[model_name] = model_runner

            logging.info('Have %d models: %s', len(self.model_runners),
                         list(self.model_runners.keys()))

        self.random_seed = random.randrange(sys.maxsize)


    def init_seq_state(self): #start_player=0
        #self.episode_seqs = []

        self.previous_fitness = -float("inf")
        self.move_count = 0
        #self.less_than_previous_count = []
        self.unuseful_move = 0
        #This should be repeated here
        #
        self.repeated_seq_ocurr = False
        #
        #self._state = string_to_one_hot(self.starting_seq, self.alphabet).astype(np.float32)
        #start = string_to_one_hot(self.starting_seq, self.alphabet).astype(np.float32)
        self._state = copy.deepcopy(self.init_state)

        #
        combo = one_hot_to_string(self._state, AAS)
        self.start_seq_exclude_list.append(combo)
        self.init_combo = combo
        # Initiation sequence addition episode_seq
        if combo not in self.episode_seqs:
            self.episode_seqs.append(combo)
        #alphafold fitness

        if_dist_peptide, if_dist_receptor, plddt, delta_CM, unrelaxed_protein = predict_function(combo,
                                                                                                 self.feature_dict,
                                                                                                 self.output_dir,
                                                                                                 self.model_runners,
                                                                                                 self.random_seed,
                                                                                                 self.receptor_if_residues,
                                                                                                 self.receptor_CAs,
                                                                                                 self.peptide_CM)
        # save alphafold result
        self.if_dist_peptide = if_dist_peptide
        self.if_dist_receptor = if_dist_receptor
        self.plddt = plddt
        self.delta_CM = delta_CM
        self.unrelaxed_protein = unrelaxed_protein
        # except:
        #     outputs = 0.0
        self.loss = (if_dist_peptide + if_dist_receptor) / 2 * 1 / plddt * delta_CM
        #reward =plddt*2/ ((if_dist_peptide + if_dist_receptor) * delta_CM)+plddt
        reward =plddt*2/ ((if_dist_peptide + if_dist_receptor) * delta_CM)

        #reward = plddt
        self._state_fitness = reward/1000 # 1000 200
            #self.plddt = plddt

        print("peptide_sequence, if_dist_peptide, if_dist_receptor, plddt, delta_CM, loss, reward, _state_fitness")
        print(combo, if_dist_peptide, if_dist_receptor, plddt, delta_CM, self.loss, reward, self._state_fitness)
        print(f"Updating New peptide feature to:{self.output_dir}/features.pkl")

        ######move#######

        self.availables = list(range(self.seq_len * self.vocab_size))


        for i, a in enumerate(combo):
            self.availables.remove(self.vocab_size*i + AAS.index(a))
        for i, e_s in enumerate(self.episode_seqs):
        #for i, e_s in enumerate(e_p_list):
            a_e_s = string_to_one_hot(e_s, AAS)
            a_e_s_ex = np.expand_dims(a_e_s, axis=0)
            if i==0:
                nda = a_e_s_ex
            else:
                nda = np.concatenate((nda, a_e_s_ex),axis=0)

        c_i_s = string_to_one_hot(combo, AAS)
        for i, aa in enumerate(combo):
            tmp_c_i_s = np.delete(c_i_s, i, axis=0)
            for slice in nda:
                tmp_slice = np.delete(slice, i, axis=0)
                if (tmp_c_i_s == tmp_slice).all():
                    bias = np.where(slice[i]!=0)[0][0]
                    to_be_removed = self.vocab_size*i + bias
                    if to_be_removed in self.availables:
                        self.availables.remove(to_be_removed)


        # for remove in self.removes:
        #     self.availables.remove(remove)
        ######move#######
        self.states = {}
        self.last_move = -1
        #
        self.previous_init_state = copy.deepcopy(self._state)
        #

    def current_state(self):

        square_state = np.zeros((self.seq_len, self.vocab_size))
        square_state = self._state
        return square_state.T
    def do_mutate(self, move, playout=0):
        # #
        # self.repeated_seq_ocurr = False
        # #
        #self.previous_state = self._state
        ##
        self.previous_fitness = self._state_fitness
        self.move_count += 1
        self.availables.remove(move)
        pos = move // self.vocab_size
        res = move % self.vocab_size

        if self._state[pos, res] == 1:
            self.unuseful_move = 1
            self._state_fitness = 0.0
        else:
            self._state[pos] = 0
            self._state[pos, res] = 1

            # #episode seq check
            # if one_hot_to_string(self._state,AAS) in self.episode_seqs:
            #     self.unuseful_move = 1
            #     self._state_fitness = 0.0
            # else:
            #     self.episode_seqs.append(one_hot_to_string(self._state,AAS))
            #previous fitness
            combo = one_hot_to_string(self._state, AAS)
            # alphafold fitness
            if playout==0:
                if combo not in self.playout_dict.keys():
                    if_dist_peptide, if_dist_receptor, plddt, delta_CM, unrelaxed_protein = predict_function(combo,self.feature_dict,
                                                                                                 self.output_dir,
                                                                                                 self.model_runners,
                                                                                                 self.random_seed,
                                                                                                 self.receptor_if_residues,
                                                                                                 self.receptor_CAs,
                                                                                                 self.peptide_CM)
                    self.loss = (if_dist_peptide + if_dist_receptor) / 2 * 1 / plddt * delta_CM
                    #reward =plddt*2/ ((if_dist_peptide + if_dist_receptor) * delta_CM)+plddt
                    reward =plddt*2/ ((if_dist_peptide + if_dist_receptor) * delta_CM)
                    #reward = plddt
                    self._state_fitness = reward/1000 # 1000 200
                    # self.playout_feature_dict[combo] = [if_dist_peptide, if_dist_receptor, plddt, delta_CM,
                    #                                    unrelaxed_protein]

                    # save alphafold result
                    self.if_dist_peptide = if_dist_peptide
                    self.if_dist_receptor = if_dist_receptor
                    self.plddt = plddt
                    self.delta_CM = delta_CM
                    self.unrelaxed_protein = unrelaxed_protein


                else:
                    self._state_fitness = self.playout_dict[combo][0]
                    self.loss = 1/(1000*self._state_fitness)

                    # save alphafold result
                    self.if_dist_peptide = self.playout_dict[combo][1]
                    self.if_dist_receptor = self.playout_dict[combo][2]
                    self.plddt = self.playout_dict[combo][3]
                    self.delta_CM = self.playout_dict[combo][4]
                    self.unrelaxed_protein = self.playout_dict[combo][5]
            else:
                if combo not in self.playout_dict.keys():

                    if_dist_peptide, if_dist_receptor, plddt, delta_CM, unrelaxed_protein = predict_function(combo,
                                                                                                             self.feature_dict,
                                                                                                             self.output_dir,
                                                                                                             self.model_runners,
                                                                                                             self.random_seed,
                                                                                                             self.receptor_if_residues,
                                                                                                             self.receptor_CAs,
                                                                                                             self.peptide_CM)
                    # save alphafold result
                    self.if_dist_peptide = if_dist_peptide
                    self.if_dist_receptor = if_dist_receptor
                    self.plddt = plddt
                    self.delta_CM = delta_CM
                    self.unrelaxed_protein = unrelaxed_protein
                    # save alphafold result
                    # except:
                    #     outputs = 0.0
                    self.loss = (if_dist_peptide + if_dist_receptor) / 2 * 1 / plddt * delta_CM
                    #reward =plddt*2/ ((if_dist_peptide + if_dist_receptor) * delta_CM)+plddt
                    reward =plddt*2/ ((if_dist_peptide + if_dist_receptor) * delta_CM)
                    #reward = plddt
                    self._state_fitness = reward/1000 # 1000 200
                    #self.plddt = plddt

                    self.playout_dict[combo] = [reward/1000, if_dist_peptide, if_dist_receptor, plddt, delta_CM, unrelaxed_protein]
                else:
                    #self._state_fitness = copy.deepcopy(self.playout_dict[combo])
                    self._state_fitness = self.playout_dict[combo][0]
                    self.loss = 1/(1000*self._state_fitness)

                    # save alphafold result
                    self.if_dist_peptide = self.playout_dict[combo][1]
                    self.if_dist_receptor = self.playout_dict[combo][2]
                    self.plddt = self.playout_dict[combo][3]
                    self.delta_CM = self.playout_dict[combo][4]
                    self.unrelaxed_protein = self.playout_dict[combo][5]

                    print('Prediction took')
                #self.plddt = 0.0
            # alphafold fitness
        #
        current_seq = one_hot_to_string(self._state, AAS)
        if current_seq in self.episode_seqs:
            self.repeated_seq_ocurr = True
            self._state_fitness = 0.0
        else:
            self.episode_seqs.append(current_seq)
        # to be evaluated
        if self._state_fitness > self.previous_fitness:  # 0.6* 0.75*   #and not repeated_seq_ocurr
            # self._state_fitness = 0.0
            #self.availables.remove(move)
            self.init_state = copy.deepcopy(self._state)
            self.init_state_count = 0
        #
        if move==0:
            self.move_0_flag = True
        #
        self.last_move = move


    def mutation_end(self):
        # to be evaluated
        if self.repeated_seq_ocurr == True:
            return True
        # to be evaluated
        if self.unuseful_move == 1:
            return True
        if self._state_fitness < self.previous_fitness:  # 0.6* 0.75*
            #print("haha")
            return True
        
        if self.move_0_flag == True:
            return True

        return False

class Mutate(object):
    """mutating server"""

    def __init__(self, Seq_env, **kwargs):
        self.Seq_env = Seq_env

    def start_p_mutating(self, player1, player2, start_player=0, is_shown=1):
        """start a game between two players"""
        if start_player not in (0, 1):
            raise Exception('start_player should be either 0 (player1 first) '
                            'or 1 (player2 first)')
        self.Seq_env.init_board(start_player)
        p1, p2 = self.Seq_env.players
        player1.set_player_ind(p1)
        player2.set_player_ind(p2)
        players = {p1: player1, p2: player2}
        if is_shown:
            self.graphic(self.Seq_env, player1.player, player2.player)
        while True:
            current_player = self.Seq_env.get_current_player()
            player_in_turn = players[current_player]
            move = player_in_turn.get_action(self.Seq_env)
            self.Seq_env.do_move(move)
            if is_shown:
                self.graphic(self.Seq_env, player1.player, player2.player)
            end, winner = self.Seq_env.game_end()
            if end:
                if is_shown:
                    if winner != -1:
                        print("Game end. Winner is", players[winner])
                    else:
                        print("Game end. Tie")
                return winner

    def start_mutating(self, mutater, is_shown=0, temp=1e-3, jumpout=50):#mutater,
        """ start mutating using a MCTS player, reuse the search tree,
        and store the self-play data: (state, mcts_probs, z) for training
        """

        if (self.Seq_env.previous_init_state == self.Seq_env.init_state).all():
            self.Seq_env.init_state_count += 1
        if self.Seq_env.init_state_count >= jumpout:  #50,10,6,7,5,8
            print("Random start replacement****")
        #     #new_start_seq = random.choice(self.Seq_env.start_seq_pool)
        #     #new_start_seq = self.Seq_env.start_seq_pool[0]
            current_start_seq = one_hot_to_string(self.Seq_env.init_state, AAS)
            episode_seqs = copy.deepcopy(self.Seq_env.episode_seqs)
            playout_seqs = copy.deepcopy(list(self.Seq_env.playout_dict.keys()))
            e_p_list = list(set(episode_seqs + playout_seqs))
            #new_start_seq = mutate_sequence(current_start_seq, self.Seq_env.start_seq_exclude_list)
            new_start_seq = mutate_sequence(current_start_seq, e_p_list)
            self.Seq_env.init_state = string_to_one_hot(new_start_seq, self.Seq_env.alphabet).astype(np.float32)
            #self.Seq_env.start_seq_pool.remove(new_start_seq)  # This will change the episode seq list
            self.Seq_env.init_state_count = 0

        self.Seq_env.init_seq_state()
        print("Start sequence：{}".format(self.Seq_env.init_combo))
        generated_peptide = []
        #alphafold_result = []
        # loss_result = []
        fit_result = []
        play_seqs_list = []
        play_losses_list = []

        if_dist_peptide_list, if_dist_receptor_list = [], []
        plddt_list, delta_CM_list = [], []
        unrelaxed_protein_list = []


        #p1, p2 = self.board.players
        states, mcts_probs, reward_z = [], [], [] #, current_players #, []
        #generated_seqs = set()
        #generated_seqs, seq_fitness,fragment_seqs = [], [], []
        while True:
            move, move_probs, play_seqs, play_losses = mutater.get_action(self.Seq_env,   #,m_p_dict
                                                 temp=temp,
                                                 return_prob=1)
            self.Seq_env.playout_dict.update(mutater.m_p_dict)
            if play_seqs:
                play_seqs_list.extend(play_seqs)
                play_losses_list.extend(play_losses)
            if move:
                # store the data
                states.append(self.Seq_env.current_state())
                mcts_probs.append(move_probs)
                reward_z.append(self.Seq_env._state_fitness)
                # add generated seqs
                # perform a move
                self.Seq_env.do_mutate(move)
                generated_peptide.append(one_hot_to_string(self.Seq_env._state, AAS))
                #alphafold_result.append(self.Seq_env.alphfold_dict)
                # loss_result.append(self.Seq_env.loss)
                fit_result.append(self.Seq_env._state_fitness)
                # AF2 feature
                if_dist_peptide_list.append(self.Seq_env.if_dist_peptide)
                if_dist_receptor_list.append(self.Seq_env.if_dist_receptor)
                plddt_list.append(self.Seq_env.plddt)
                delta_CM_list.append(self.Seq_env.delta_CM)
                unrelaxed_protein_list.append(self.Seq_env.unrelaxed_protein)

                print("move_fitness: %.16f\n" % (self.Seq_env._state_fitness))
                #print("plddt: %.16f\n" % (self.Seq_env.plddt))
                print("loss: %.16f\n" % (self.Seq_env.loss))
                print("episode_seq len: %d\n" % (len(self.Seq_env.episode_seqs)))
                print("Mmove & playout dict len: %d\n" % (len(self.Seq_env.playout_dict)))
                state_string = one_hot_to_string(self.Seq_env._state, AAS)
                #self.Seq_env.start_seq_exclude_list.append(state_string)
                print(state_string)
                # generated_seqs.add(one_hot_to_string(self.Seq_env._state, AAS))
                # combo_str = one_hot_to_string(self.Seq_env._state, AAS)
                # full_len_mutation_seq = map_to_full_len_gfp(gluc_wt_sequence, map_dict, combo_str)
                # generated_seqs.append(full_len_mutation_seq)
                # seq_fitness.append(float(self.Seq_env._state_fitness))
                # fragment_seqs.append(combo_str)
                # generated_seqs

            end = self.Seq_env.mutation_end()
            if end:
                mutater.reset_Mutater()
                if is_shown:

                    print("Mutation end.")
                playout_dict = copy.deepcopy(self.Seq_env.playout_dict)
                return zip(states, mcts_probs, reward_z), zip(generated_peptide, fit_result, if_dist_peptide_list,
                                                                              if_dist_receptor_list,
                                                                              plddt_list, delta_CM_list,
                                                                              unrelaxed_protein_list), \
                       play_seqs_list, play_losses_list, playout_dict #, zip(generated_seqs, seq_fitness, fragment_seqs)#generated_seqs#winner,  #alphafold_result

