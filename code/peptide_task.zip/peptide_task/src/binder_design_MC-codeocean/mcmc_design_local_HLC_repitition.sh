IDS=../../../../data/peptide_data/LNR_set_12sub.csv # LNR_set.csv

# 剔除第一行的header，从第二行出发
# for i in {2..13}

### 取蛋白
i=2 # 1ssc:2, 2cnz:4, 3r7g:8, 3vxw:10, 6seo:13

### '1ssc', # start sequence，第一条为天然序列
SEQUENCEs=('PYVPVHFDASV' 'CKQRSLCYHLS' 'CWLQCRNSLTH' 'EPSNACCNMPS' 'SSAMAKAVAFQ' 'YHAYNWWSMKC')
### '2cnz' 
# SEQUENCEs=('GSFLPNSEQQKSADIVFSSP', 'RTWQCSGMFPFYKLRASIFS',
#            'RVRFWCMTMWVTQDYMKIVL', 'MCERMWQYFWPCHKQAVDQY', 
#            'CLTCGVHHPLTMGCCLRTTL', 'MFCWNCRIYLTKFAFQFWVR')
### '3r7g'
# SEQUENCEs=('KSLYKIKPRHDSGIKAKISMKT' 'SAFMNEPKYQVQICWLFMQVPQ' 'LFFVPDTSIWQFLEMDTETVYT' 'QHTMSATRFNEWWWNESWMKPA' 'CRKAWLEVIIYSHQADKGFVYL' 'YDMEYHWMSMQSPYCCMEKCIG')
### '3vxw'
# SEQUENCEs=('nothing' 'ACTVKR', 'DLYFID', 'CNTQSG', 'ALYHYY', 'LYCKTN')
### '6seo'
# SEQUENCEs=('XVPLRARNLPPSFFTEPX' 'CMEYTHFDPWNVLDIWLT', 'IPMYGLHTYCLYIGQTPD', 'WGSREDGCQQLFNNCQAY', 'YASVPEWAEFNAFSDTKM', 'GTPAYYCIMWSDPTKLIT') 


MAX_RECYCLES=0 #max_recycles (default=3)
MODEL_NAME='model_1' #model_1_ptm

#NUMBER OF ITERATIONS
NITER=2

# for SEQ_IDX in {1..5}
# for SEQ_IDX in 1 5
for SEQ_IDX in 5
do
    SEQUENCE=${SEQUENCEs[${SEQ_IDX}]}
    echo 'Start sequence:'$SEQUENCE

    ####5组####
    for IDX in 6
    do
        echo 'Sequence'$SEQ_IDX 'Repitition'$IDX
        RECEPTOR_CHAIN=$(sed -n $i'p' $IDS|cut -d ',' -f 4)
        RECEPTOR=$(sed -n $i'p' $IDS|cut -d ',' -f 3)
        RECEPTORID=$RECEPTOR'_'$RECEPTOR_CHAIN
        echo RECEPTORID $RECEPTORID
        # RECEPTORID=1fiw_A #1fiw_A 1ssc_A

        ####Get fasta file####
        FASTADIR=../../../../data/peptide_data/fasta
        RECEPTORFASTA=$FASTADIR/receptor/$RECEPTORID'.fasta'
        echo RECEPTORFASTA $RECEPTORFASTA

        ###Get peptide length###
        # PEPTIDELENGTH=14
        # STR=$(sed -n 2'p' ../data/LNR_set.csv|cut -d ',' -f 7)
        STR=$(sed -n $i'p' $IDS|cut -d ',' -f 7)
        PEPTIDELENGTH=${#STR}
        echo PEPTIDELENGTH $PEPTIDELENGTH

        ###Peptide centre of mass###
        # PEPTIDE_CM='/alldata/LChuang_data/workspace/Project/Protein_design/EvoBind-master/binder_design-master/data/PDB/'$RECEPTOR'_CM.npy'
        PEPTIDE_CM='../../../../data/peptide_data/PDB/'$RECEPTOR'_CM.npy'
        echo PEPTIDE_CM $PEPTIDE_CM

        #########Step1: Create MSA with HHblits#########
        #HHblits
        MSADIR=../../../../data/peptide_data/MSA_dir/
        HHBLITSDB=./uniclust30/uniclust30_2018_08/uniclust30_2018_08

        #Write individual fasta files for all unique sequences
        if test -f $MSADIR/$RECEPTORID'.a3m'; then
            echo $MSADIR/$RECEPTORID'.a3m' exists
        else
            echo hhblits -i $RECEPTORFASTA -d $HHBLITSDB -E 0.001 -all -n 2 -oa3m $MSADIR/$RECEPTORID'.a3m'
            hhblits -i $RECEPTORFASTA -d $HHBLITSDB -E 0.001 -all -n 2 -oa3m $MSADIR/$RECEPTORID'.a3m'
        fi
        #MSA
        # MSA=$DATADIR/$RECEPTORID'.a3m'
        MSA=$MSADIR/$RECEPTORID'.a3m'
        echo MSA $MSA

        ###Get receptor interface residues
        RECEPTORDIR=../../../../data/peptide_data/PDB/receptor
        RECEPTORIFRES=$RECEPTORDIR/$RECEPTORID'_if.npy'
        echo RECEPTORIFRES $RECEPTORIFRES

        #Receptor CAs
        RECEPTOR_CAS='../../../../data/peptide_data/PDB/'$RECEPTOR'_receptor_CA.npy'
        echo RECEPTOR_CAS $RECEPTOR_CAS

        ##### AF2 CONFIGURATION #####
        AFHOME='./'

        ### path of param folder containing AF2 Neural Net parameters.
        ### download from: https://storage.googleapis.com/alphafold/alphafold_params_2021-07-14.tar)
        PARAM=../../AF/  # /home/pbryant/data/af_params/

        ### Running options for obtaining a refines tructure ###
        INIT_IND='test_fixed_seqence_'$SEQ_IDX'_repitition'$IDX # 'test_5' # 'test_fixed_seqence_3' # 'test_fixed_seqence_2'

        MSAS="$MSA" #Comma separated list of msa paths

        ### Path where AF2 generates its output folder structure
        # OUTFOLDER='../data/reproduct_dir/'$RECEPTORID'_test_havebug_recycle0/'
        OUTFOLDER='../../results/MCMC_output/'$RECEPTORID'_'$INIT_IND'_recycle'$MAX_RECYCLES'/'
        echo OUTFOLDER $OUTFOLDER

        # 指定起始序列
        python $AFHOME/mcmc_design_LChuang.py \
                --receptor_fasta_path=$RECEPTORFASTA \
                --receptor_if_residues=$RECEPTORIFRES \
                --receptor_CAs=$RECEPTOR_CAS \
                --peptide_length=$PEPTIDELENGTH \
                --peptide_CM=$PEPTIDE_CM \
                --msas=$MSAS \
                --output_dir=$OUTFOLDER \
                --model_names=$MODEL_NAME \
                --data_dir=$PARAM \
                --max_recycles=$MAX_RECYCLES \
                --num_iterations=$NITER \
                --peptide_sequence=$SEQUENCE \
                --predict_only=False


        ## 不指定起始序列
        #python $AFHOME/mcmc_design_LChuang.py \
        #        --receptor_fasta_path=$RECEPTORFASTA \
        #        --receptor_if_residues=$RECEPTORIFRES \
        #        --receptor_CAs=$RECEPTOR_CAS \
        #        --peptide_length=$PEPTIDELENGTH \
        #        --peptide_CM=$PEPTIDE_CM \
        #        --msas=$MSAS \
        #        --output_dir=$OUTFOLDER \
        #        --model_names=$MODEL_NAME \
        #        --data_dir=$PARAM \
        #        --max_recycles=$MAX_RECYCLES \
        #        --num_iterations=$NITER \
        #        --MCMC_T0=$MCMC_T0 \
        #        --MCMC_coef=$MCMC_coef \
        #        --MCMC_M=$MCMC_M \
        #        --predict_only=False

        echo RECEPTORID $RECEPTORID
        echo '-------Finished!-------'

    done
done
