IDS=../data/LNR_set_12sub.csv # LNR_set.csv


# 剔除第一行的header，从第二行出发
# for i in {2..13}

# i=2   # 取1ssc蛋白，为第2行，i=2
# i=8  # 取3r7g蛋白，为第9行，i=9
# i=10  # 取3vxw蛋白，为第10行，i=10
i=13  # 取6seo蛋白，为第9行，i=9
# {'1ssc': ['PYVPVHFDASV', 'CKQRSLCYHLS', 'CWLQCRNSLTH', 'EPSNACCNMPS', 'SSAMAKAVAFQ', 'YHAYNWWSMKC'], '3r7g': ['KSLYKIKPRHDSGIKAKISMKT', 'SAFMNEPKYQVQICWLFMQVPQ', 'LFFVPDTSIWQFLEMDTETVYT', 'QHTMSATRFNEWWWNESWMKPA', 'CRKAWLEVIIYSHQADKGFVYL', 'YDMEYHWMSMQSPYCCMEKCIG'], '3vxw': ['SWQAIQ', 'ACTVKR', 'DLYFID', 'CNTQSG', 'ALYHYY', 'LYCKTN'], '6seo': ['XVPLRARNLPPSFFTEPX', 'CMEYTHFDPWNVLDIWLT', 'IPMYGLHTYCLYIGQTPD', 'WGSREDGCQQLFNNCQAY', 'YASVPEWAEFNAFSDTKM', 'GTPAYYCIMWSDPTKLIT']}

### 1ssc', # start sequence，第一条填充用的
# SEQUENCEs=('nothing' 'CKQRSLCYHLS' 'CWLQCRNSLTH' 'EPSNACCNMPS' 'SSAMAKAVAFQ' 'YHAYNWWSMKC')
### '3r7g'
# SEQUENCEs=('nothing' 'SAFMNEPKYQVQICWLFMQVPQ' 'LFFVPDTSIWQFLEMDTETVYT' 'QHTMSATRFNEWWWNESWMKPA' 'CRKAWLEVIIYSHQADKGFVYL' 'YDMEYHWMSMQSPYCCMEKCIG')
### '3vxw'
#SEQUENCEs=('nothing' 'ACTVKR', 'DLYFID', 'CNTQSG', 'ALYHYY', 'LYCKTN')
### '6seo'
SEQUENCEs=('nothing' 'CMEYTHFDPWNVLDIWLT', 'IPMYGLHTYCLYIGQTPD', 'WGSREDGCQQLFNNCQAY', 'YASVPEWAEFNAFSDTKM', 'GTPAYYCIMWSDPTKLIT') 


# for SEQ_IDX in {1..5}
# for SEQ_IDX in 1 5
for SEQ_IDX in {1..5}
do
    SEQUENCE=${SEQUENCEs[${SEQ_IDX}]}
    echo 'Start sequence:'$SEQUENCE

    ####4组即可####
    for IDX in {6..7}
    do
        echo 'Sequence'$SEQ_IDX 'Repitition'$IDX
        RECEPTOR_CHAIN=$(sed -n $i'p' $IDS|cut -d ',' -f 4)
        RECEPTOR=$(sed -n $i'p' $IDS|cut -d ',' -f 3)
        RECEPTORID=$RECEPTOR'_'$RECEPTOR_CHAIN
        echo RECEPTORID $RECEPTORID
        # RECEPTORID=1fiw_A #1fiw_A 1ssc_A

        ####Get fasta file####
        FASTADIR=/alldata/LChuang_data/workspace/Project/Protein_design/EvoBind-master/binder_design-master/data/fasta
        RECEPTORFASTA=$FASTADIR/receptor/$RECEPTORID'.fasta'
        echo RECEPTORFASTA $RECEPTORFASTA

        ###Get peptide length###
        # PEPTIDELENGTH=14
        # STR=$(sed -n 2'p' ../data/LNR_set.csv|cut -d ',' -f 7)
        STR=$(sed -n $i'p' $IDS|cut -d ',' -f 7)
        PEPTIDELENGTH=${#STR}
        echo PEPTIDELENGTH $PEPTIDELENGTH

        ###Peptide centre of mass###
        PEPTIDE_CM='/alldata/LChuang_data/workspace/Project/Protein_design/EvoBind-master/binder_design-master/data/PDB/'$RECEPTOR'_CM.npy'
        echo PEPTIDE_CM $PEPTIDE_CM

        #########Step1: Create MSA with HHblits#########
        #HHblits
        MSADIR=/alldata/LChuang_data/workspace/Project/Protein_design/EvoBind-master/binder_design-master/data/reproduct_dir/MSA_dir/
        HHBLITSDB=/alldata/LChuang_data/workspace/Project/Alphafold_local/download/uniclust30/uniclust30_2018_08/uniclust30_2018_08

        #Write individual fasta files for all unique sequences
        if test -f $MSADIR/$RECEPTORID'.a3m'; then
            echo $MSADIR/$RECEPTORID'.a3m' exists
        else
            echo hhblits -i $RECEPTORFASTA -d $HHBLITSDB -E 0.001 -all -n 2 -oa3m $MSADIR/$RECEPTORID'.a3m'
            hhblits -i $RECEPTORFASTA -d $HHBLITSDB -E 0.001 -all -n 2 -oa3m $MSADIR/$RECEPTORID'.a3m'
        fi
        #MSA
        # MSA=$DATADIR/$RECEPTORID'.a3m'
        MSA=$MSADIR/$RECEPTORID'.a3m'
        echo MSA $MSA

        ###Get receptor interface residues
        RECEPTORDIR=../data/PDB/receptor
        RECEPTORIFRES=$RECEPTORDIR/$RECEPTORID'_if.npy'
        echo RECEPTORIFRES $RECEPTORIFRES

        #Receptor CAs
        RECEPTOR_CAS='../data/PDB/'$RECEPTOR'_receptor_CA.npy'
        echo RECEPTOR_CAS $RECEPTOR_CAS

        ##### AF2 CONFIGURATION #####
        AFHOME='./'

        #Singularity image
        # IMG=/home/pbryant/singularity_ims/af_torch_sbox

        ### path of param folder containing AF2 Neural Net parameters.
        ### download from: https://storage.googleapis.com/alphafold/alphafold_params_2021-07-14.tar)
        PARAM=/alldata/LChuang_data/workspace/Project/Protein_design/EvoBind-master/data/AF/  # /home/pbryant/data/af_params/

        ### Running options for obtaining a refines tructure ###
        INIT_IND='test_fixed_seqence_'$SEQ_IDX'_repitition'$IDX # 'test_5' # 'test_fixed_seqence_3' # 'test_fixed_seqence_2'
        MAX_RECYCLES=0 #max_recycles (default=3)
        MODEL_NAME='model_1' #model_1_ptm
        MSAS="$MSA" #Comma separated list of msa paths


        #NUMBER OF ITERATIONS
        NITER=1000

        #Regarding the run mode
        # SINGULARITY=/opt/singularity3/bin/singularity
        # $SINGULARITY exec --nv $IMG \

        ### Path where AF2 generates its output folder structure
        # OUTFOLDER='../data/reproduct_dir/'$RECEPTORID'_test_havebug_recycle0/'
        OUTFOLDER='/alldata/LChuang_data/workspace/Project/Protein_design/EvoBind-master/binder_design-master/data/reproduct_dir/'$RECEPTORID'_'$INIT_IND'_recycle'$MAX_RECYCLES'/'
        echo OUTFOLDER $OUTFOLDER

        # 指定起始序列
        python $AFHOME/mc_design.py \
                --receptor_fasta_path=$RECEPTORFASTA \
                --receptor_if_residues=$RECEPTORIFRES \
                --receptor_CAs=$RECEPTOR_CAS \
                --peptide_length=$PEPTIDELENGTH \
                --peptide_CM=$PEPTIDE_CM \
                --msas=$MSAS \
                --output_dir=$OUTFOLDER \
                --model_names=$MODEL_NAME \
                --data_dir=$PARAM \
                --max_recycles=$MAX_RECYCLES \
                --num_iterations=$NITER \
                --peptide_sequence=$SEQUENCE \
                --predict_only=False


        ## 不指定起始序列
        #python $AFHOME/mc_design.py \
        #        --receptor_fasta_path=$RECEPTORFASTA \
        #        --receptor_if_residues=$RECEPTORIFRES \
        #        --receptor_CAs=$RECEPTOR_CAS \
        #        --peptide_length=$PEPTIDELENGTH \
        #        --peptide_CM=$PEPTIDE_CM \
        #        --msas=$MSAS \
        #        --output_dir=$OUTFOLDER \
        #        --model_names=$MODEL_NAME \
        #        --data_dir=$PARAM \
        #        --max_recycles=$MAX_RECYCLES \
        #        --num_iterations=$NITER \
        #        --predict_only=False

        echo RECEPTORID $RECEPTORID
        echo '-------Finished!-------'

    done
done
