###### Peptide design for 1ssc was carried out for 2 rounds (1000 rounds in the paper). NITER=2
###### Parameters ######
# INIT_NUM='1'
# SLEEP=0
PLAYOUT_NUM=11
BATCH_SIZE=32
RECYCLE_NUM=0
JUMPOUT=32
C_PUCT=0.5
NITER=5
WORKDIR='./'
OUTPUT_DIR='../../results/EvoZero_output/'
MSADIR='../../data/peptide_data/MSA_dir/'
IDS='../../data/peptide_data/LNR_set_12sub.csv'

###### Start sequence. The first one is for filling ######
### 1ssc
PDBID='1ssc'
SEQUENCEs=('nothing' 'CKQRSLCYHLS')

for SEQ_IDX in {1..1}
do
    ## select fixed sequence for benchmark
    SEQUENCE=${SEQUENCEs[${SEQ_IDX}]}
    echo 'Start sequence:'$SEQUENCE
    INIT_NUM=$SEQ_IDX
    SLEEP=$SEQ_IDX
    
    python $WORKDIR/evozero_peptide_expand_m_p.py \
    --ids $IDS \
    --output_dir $OUTPUT_DIR \
    --n_playout $PLAYOUT_NUM \
    --init_num $INIT_NUM \
    --batch_size $BATCH_SIZE \
    --pdbid $PDBID \
    --recycle_num $RECYCLE_NUM \
    --jumpout $JUMPOUT \
    --c_puct $C_PUCT \
    --niter $NITER \
    --sleep $SLEEP \
    --start_sequence $SEQUENCE
    echo PDBID $PDBID
    echo '-------Finished!-------'
    
done
