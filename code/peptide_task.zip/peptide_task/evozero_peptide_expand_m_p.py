"""
Modifed by LiChaohuang, Yiwang
"""


from __future__ import print_function
import argparse
import random
from collections import defaultdict, deque
from sequence_env_alphfold_expand_m_p import Seq_env, Mutate
from mcts_alphaZero_mutate_expand_m_p import MCTSMutater
# from p_v_net_torch import PolicyValueNet  # Pytorch
from p_v_net_2 import PolicyValueNet
# from env_model import CNN
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torch.utils.data as data
from torch.utils.data import DataLoader
import time
from datetime import datetime

from sklearn.cluster import KMeans
from sklearn.gaussian_process import GaussianProcessRegressor
import os
import pandas as pd
import pdb
import json

# save unrelaxed pdb
def save_design(unrelaxed_protein, output_dir, model_name, l1):
    '''Save the resulting protein-peptide design to a pdb file
    '''

    unrelaxed_pdb_path = os.path.join(output_dir, f'unrelaxed_{model_name}.pdb')
    chain_name = 'A'
    with open(unrelaxed_pdb_path, 'w') as f:
        from alphafold.common import protein
        pdb_contents = protein.to_pdb(unrelaxed_protein).split('\n')
        for line in pdb_contents:
            try:
                record = parse_atm_record(line)
                if record['res_no'] > l1:
                    chain_name = 'B'
                outline = line[:21] + chain_name + line[22:]
                f.write(outline + '\n')
            except:
                f.write(line + '\n')

def initialize_weights(peptide_length):
    '''Initialize sequence probabilities
    '''
    weights = np.random.gumbel(0, 1, (peptide_length, 20))
    weights = np.array([np.exp(weights[i]) / np.sum(np.exp(weights[i])) for i in range(len(weights))])

    # Get the peptide sequence
    # Residue types
    restypes = np.array(['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I',
                         'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V'])

    peptide_sequence = ''.join(restypes[[x for x in np.argmax(weights, axis=1)]])

    return weights, peptide_sequence

###
def string_to_one_hot(sequence: str, alphabet: str) -> np.ndarray:
    out = np.zeros((len(sequence), len(alphabet)))
    for i in range(len(sequence)):
        out[i, alphabet.index(sequence[i])] = 1
    return out


# train rgre model

AAS = "ARNDCQEGHILKMFPSTWYV"


def feature_single(variant):
    Feature = []
    aalist = list(AAS)
    for AA in variant:
        Feature.append([AA == aa for aa in aalist])
    Feature = np.asarray(Feature).astype(float)
    if len(Feature.shape) == 2:
        features = np.reshape(Feature, [Feature.shape[0] * Feature.shape[1]])

    return features


class TrainPipeline():
    def __init__(self, pdbid, start_seq, n_playout, batch_size, alphabet, feature_output_dir, recycle_num, niter, c_puct, jumpout, trust_radius,
                 init_model=None):  # init_model=None  feature_list, #, combo_feature_map, combo_index_map, first_round_index, round,
        # params of the board and the game
        # self.seq_len = len(start_seq_pool[0])
        self.pdbid = pdbid
        self.seq_len = len(start_seq)
        self.vocab_size = len(alphabet)
        self.n_in_row = 4

        self.round = round
        self.feature_output_dir = feature_output_dir

        self.seq_env = Seq_env(
            self.seq_len,
            alphabet,
            # model,
            self.pdbid,
            start_seq,
            self.feature_output_dir,
            recycle_num, 
            # combo_feature_map,
            # first_round_index,
            # combo_index_map,
            # first_round_combo,
            # feature_list,
            trust_radius)  # n_in_row=self.n_in_row
        self.mutate = Mutate(self.seq_env)
        # training params
        self.learn_rate = 2e-3
        self.lr_multiplier = 1.0  # adaptively adjust the learning rate based on KL
        self.temp = 1.0  # the temperature param
        self.n_playout = n_playout  # num of simulations for each move 400  #16
        self.c_puct = c_puct # 5 10
        self.jumpout = jumpout #50/6/10 or to set 1000 for nojump
        self.buffer_size = niter
        self.batch_size = batch_size  # mini-batch size for training  512  # 16， 8, 16
        self.data_buffer = deque(maxlen=self.buffer_size)
        self.play_batch_size = 1
        self.epochs = 5  # num of train_steps for each update
        self.kl_targ = 0.02
        self.check_freq = 50
        self.game_batch_num = niter  # 1500
        self.best_win_ratio = 0.0
        # num of simulations used for the pure mcts, which is used as
        # the opponent to evaluate the trained policy
        self.pure_mcts_playout_num = 1000
        # self_added
        self.buffer_no_extend = False

        self.update_predictor = 0
        self.updata_predictor_index_set = set()
        self.collected_seqs = set()  ###gluc
        self.seqs_and_fitness = []  ####gluc

        # peptide unique
        self.generated_peptides = []
        self.alphafold_results = []
        self.loss_list = []
        self.play_seq_list = []
        self.play_loss_list = []
        self.p_dict = {}
        self.m_p_dict = {}

        self.if_dist_peptide, self.if_dist_receptor = [], []
        self.plddt, self.delta_CM, self.state_fitness = [], [], []
        self.unrelax_pdb = []
        self.unrelax_idx = 0

        # peptide unique
        print("###### Load an initial policy-value net ######")
        if init_model:
            # start training from an initial policy-value net
            self.policy_value_net = PolicyValueNet(self.seq_len,
                                                   self.vocab_size,
                                                   model_file=init_model, use_gpu=True)
        else:
            # start training from a new policy-value net
            self.policy_value_net = PolicyValueNet(self.seq_len,
                                                   self.vocab_size, use_gpu=True)
        print("###### Load MCTSMutater ######")
        self.mcts_player = MCTSMutater(self.policy_value_net.policy_value_fn,
                                       c_puct=self.c_puct,
                                       n_playout=self.n_playout,
                                       is_selfplay=1)

    def collect_selfplay_data(self, n_games=1):
        """collect self-play data for training"""
        #
        self.update_predictor = 0
        #
        self.buffer_no_extend = False
        play_seq_list = []
        play_loss_list = []
        for i in range(n_games):
            play_data, peptied_and_alphafold, play_seq, play_losses, p_dict = self.mutate.start_mutating(
                self.mcts_player,  # , seqs_and_fitness
                temp=self.temp, jumpout=self.jumpout)  # winner,
            play_data = list(play_data)[:]
            self.episode_len = len(play_data)
            #
            self.p_dict = p_dict  # seq&loss
            self.m_p_dict.update(self.p_dict)  # move and playout seq&loss

            #
            if self.episode_len == 0:
                self.buffer_no_extend = True
            # augment the data
            # play_data = self.get_equi_data(play_data)
            else:
                self.data_buffer.extend(play_data)
                for pep, loss, if_pep, if_rep, plddt, delta_cm, un_pdb in peptied_and_alphafold:  # alphafold_d
                    # pdb.set_trace()
                    if pep not in self.generated_peptides:
                        # move: seq and loss
                        self.generated_peptides.append(pep)
                        self.loss_list.append(loss)
                        # feature
                        self.if_dist_peptide.append(if_pep)
                        self.if_dist_receptor.append(if_rep)
                        self.plddt.append(plddt)
                        self.delta_CM.append(delta_cm)
                        self.unrelax_pdb.append(un_pdb)

                    # combine move and play seqs
                    if pep not in self.m_p_dict.keys():
                        # playout: seq and loss
                        self.m_p_dict[pep] = [loss, if_pep, if_rep, plddt, delta_cm, un_pdb]

                        # combine move and play seqs

                self.play_seq_list.extend(play_seq)
                self.play_loss_list.extend(play_losses)

    def policy_update(self):
        """update the policy-value net"""
        mini_batch = random.sample(self.data_buffer, self.batch_size)
        state_batch = [data[0] for data in mini_batch]
        mcts_probs_batch = [data[1] for data in mini_batch]
        winner_batch = [data[2] for data in mini_batch]
        old_probs, old_v = self.policy_value_net.policy_value(state_batch)
        for i in range(self.epochs):
            loss, entropy = self.policy_value_net.train_step(
                state_batch,
                mcts_probs_batch,
                winner_batch,
                self.learn_rate * self.lr_multiplier)
            new_probs, new_v = self.policy_value_net.policy_value(state_batch)
            kl = np.mean(np.sum(old_probs * (
                    np.log(old_probs + 1e-10) - np.log(new_probs + 1e-10)),
                                axis=1)
                         )
            if kl > self.kl_targ * 4:  # early stopping if D_KL diverges badly
                break
        # adaptively adjust the learning rate
        if kl > self.kl_targ * 2 and self.lr_multiplier > 0.1:
            self.lr_multiplier /= 1.5
        elif kl < self.kl_targ / 2 and self.lr_multiplier < 10:
            self.lr_multiplier *= 1.5

        explained_var_old = (1 -
                             np.var(np.array(winner_batch) - old_v.flatten()) /
                             np.var(np.array(winner_batch)))
        explained_var_new = (1 -
                             np.var(np.array(winner_batch) - new_v.flatten()) /
                             np.var(np.array(winner_batch)))
        print(("kl:{:.5f},"
               "lr_multiplier:{:.3f},"
               "loss:{},"
               "entropy:{},"
               "explained_var_old:{:.3f},"
               "explained_var_new:{:.3f}"
               ).format(kl,
                        self.lr_multiplier,
                        loss,
                        entropy,
                        explained_var_old,
                        explained_var_new))
        return loss, entropy

    def run(self, output_dir="./output/init0/"):
        """run the training pipeline"""
        try:

            num_old = 0
            for i in range(self.game_batch_num):
                self.collect_selfplay_data(self.play_batch_size)
                print("batch i:{}, episode_len:{}".format(
                    i + 1, self.episode_len))

                # saving move
                df_w = pd.DataFrame(
                    {"peptide": self.generated_peptides, "loss": self.loss_list})
                df_w.to_csv(f"{output_dir}/move.csv", index=False)
                # saving move

                # saving play_data
                df_play = pd.DataFrame(
                    {"play_peptide": self.play_seq_list, "play_loss": self.play_loss_list})
                df_play.to_csv(f"{output_dir}/play.csv", index=False)
                # saving play_data

                # saving unique p dict
                p_losses = np.array(list(self.p_dict.values()))[:, 0]
                p_fitness = 1 / (p_losses * 1000)
                p_seqs = np.array(list(self.p_dict.keys()))
                df_p = pd.DataFrame(
                    {"peptide": p_seqs, "loss": p_fitness})
                df_p.to_csv(f"{output_dir}/unique_playout.csv", index=False)
                # saving unique p dict

                # saving m & p dict
                m_p_losses = np.array(list(self.m_p_dict.values()))[:, 0]
                m_p_fitness = 1 / (m_p_losses * 1000)
                m_p_seqs = np.array(list(self.m_p_dict.keys()))
                df_m_p = pd.DataFrame(
                    {"peptide": m_p_seqs, "loss": m_p_fitness})
                df_m_p.to_csv(f"{output_dir}/Mmove_and_playout.csv", index=False)

                
                print(i + 1, "Saving!")  # Unified storage, avoid dislocation
                # loss, if_pep, if_rep, plddt, delta_cm, un_pdb = v[-1]
                # m_p_loss = np.array(m_p_fitness)
                m_p_seqs = np.array(list(self.m_p_dict.keys()))
                m_p_if_pep = np.array(list(self.m_p_dict.values()))[:, 1]
                m_p_if_rep = np.array(list(self.m_p_dict.values()))[:, 2]
                m_p_plddt = np.array(list(self.m_p_dict.values()))[:, 3]
                m_p_delta_cm = np.array(list(self.m_p_dict.values()))[:, 4]
                np.save(output_dir + 'loss.npy', np.array(m_p_fitness))
                np.save(output_dir + 'sequence.npy', m_p_seqs)
                np.save(output_dir + 'if_dist_peptide.npy', m_p_if_pep)
                np.save(output_dir + 'if_dist_receptor.npy', m_p_if_rep)
                np.save(output_dir + 'plddt.npy', m_p_plddt)
                np.save(output_dir + 'delta_CM.npy', m_p_delta_cm)

                
                # v = [loss, if_pep, if_rep, plddt, delta_cm, un_pdb]
                if len(self.m_p_dict.keys()) >= self.game_batch_num:   # stop condition 200  ,1000
                    # Saving pdb
                    for k, v in self.m_p_dict.items():
                        un_pdb = v[-1]
                        save_design(un_pdb, output_dir, self.unrelax_idx, self.seq_len)
                        self.unrelax_idx += 1
                        print("Saving pdb playout: ", self.unrelax_idx)
                    break

                if len(self.data_buffer) > self.batch_size and self.buffer_no_extend == False:
                    loss, entropy = self.policy_update()

        except KeyboardInterrupt:
            print('\n\rquit')


if __name__ == '__main__':

    """
    USAGE2:
        python peptide_mcts_alphfold_expand_m_p.py --n_playout 22 --init_num 1 --niter 2000 --batch_size 32 --pdbid "1ssc" --recycle_num 0 --start_sequence "EPSNACCNMPS" 
    """

    parser = argparse.ArgumentParser(description='MCTS_Evobind')
    parser.add_argument("--output_dir", type=str,
                        default="/alldata/LChuang_data/workspace/Project/Protein_design/MCTS_evobind/output/",
                        help="output data dir")
    parser.add_argument("--start_sequence", type=str,
                        default=None, help="start sequence")
    parser.add_argument("--pdbid", type=str,
                        default='1ssc', help="pdb id")
    parser.add_argument("--n_playout", type=int, default=11,
                        help="number of n_playout")
    parser.add_argument("--init_num", type=str, default='1',
                        help="init seed")
    parser.add_argument("--batch_size", type=int, default=32,
                        help="MCTS batch_size")
    parser.add_argument("--recycle_num", type=int, default=0,
                        help="Alphafold2 recycle num")
    parser.add_argument("--niter", type=int, default=1000,
                        help="iter num")
    parser.add_argument("--jumpout", type=int, default=1000,
                        help="1000 for nojump. For 3r7g and 6seo, default=50. For 1ssc, default=10 and 1000")
    parser.add_argument("--c_puct", type=float, default=3,
                        help="a number in (0, inf) that controls how quickly exploration converges to the maximum-value policy. \
                        A higher value means relying on the prior more.\
                        option:0.5/2/5/10, defalut=3")
    parser.add_argument("--sleep", type=int,
                        default=0, help="Sleep a few second to avoid resource runs out")
    parser.add_argument("--ids", type=str,
                        default="xxx",
                        help="IDS path")
    args = parser.parse_args()
    
    
    ## Sleep setting to avoid resource runs out
    if int(args.sleep) > 0:
        # sleep_time = np.random.randint(1,10)*5
        sleep_time = args.sleep*5
        print("sleep_time:", sleep_time)
        time.sleep(sleep_time)

    
    # ### NVIDIA Setting
    # cmd = "nvidia-smi -q -d Memory |grep -A4 GPU|grep Free"
    # print('cmd: ', cmd)
    # process = os.popen(cmd)  # return file
    # output = process.read()
    # print(output)
    # process.close()
    # memory_gpu = [int(x.split()[2]) for x in output.strip().split('\n')]
    # print([str(ii) + ':' + str(v) for ii, v in enumerate(memory_gpu)])
    # print('max remain memory GPU:', str(np.argmax(memory_gpu)))
    # set gpu env
    os.environ['CUDA_VISIBLE_DEVICES'] = '0' # str(np.argmax(memory_gpu))
    

    # start_time
    start_time = datetime.now()
    print("The current date and time is", start_time)

    init_num_list = args.init_num
    init_num_list = init_num_list.split(',')

    n_playout = args.n_playout  # 5/50/100
    base_output_dir = args.output_dir
    batch_size = args.batch_size
    recycle_num = args.recycle_num
    niter = args.niter
    c_puct = args.c_puct
    jumpout = args.jumpout
    pdbid = args.pdbid  # '1ssc' args.pdbid
    IDS= args.ids  # "./data/LNR_set_12sub.csv"
    IDS_df = pd.read_csv(IDS)
    tmp_df = IDS_df[IDS_df['pdb_id']==pdbid]
    start_sequence = args.start_sequence
    

    for init_num in init_num_list:
        # init_num = args.init_num

        # Set random seeds
        init_num = int(init_num)
        seed = 50 + init_num  # init_1，seed=51
        np.random.seed(seed)
        random.seed(seed)

        # set peptide start pool
        AAS = "ARNDCQEGHILKMFPSTWYV"  # dafault 20AAs
        peptide_length = tmp_df['peptide_length'].values[0]  # args.peptide_length  # 11
        print(peptide_length, type(peptide_length))
        start_pool = []
        pool_size = 1

        if start_sequence == None:
            print(f"No starting sequence is specified. Samples will be randomly sampled {pool_size}")
            # Initialize weights - these are the amino acid probabilities
            # Also returns the peptide_sequence corresponding to the weights
            for i in range(pool_size):
                seq_weights, peptide_sequence = initialize_weights(peptide_length)
                start_sequence = peptide_sequence
                start_pool.append(start_sequence)
        else:
            print("Specify the starting sequence:", start_sequence)
            start_pool = []
            start_pool.append(start_sequence)

        start_sequence = start_pool[0]
        output_dir = f"{base_output_dir}/{pdbid}/{pdbid}_{start_sequence}_init_{init_num}/"  #
        print("output_dir: \n", output_dir)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        # Output the args file and save the hyperparameters
        with open(f'{output_dir}/commandline_args.txt', 'w') as f:
            json.dump(args.__dict__, f, indent=2)

        df = pd.DataFrame({"random_seq": np.array(start_pool)})
        df.to_csv(f"{output_dir}/StartPool_gumbel_init0.csv")
        print(df)

        feature_output_dir = os.path.join(output_dir, pdbid)
        if not os.path.exists(feature_output_dir):
            os.makedirs(feature_output_dir)

        # random.shuffle(start_pool)
        training_pipeline = TrainPipeline(
            pdbid,
            # ep_start_pool,  # max start
            start_sequence,  # rand start
            # start_pool,
            n_playout,
            batch_size,
            AAS,
            feature_output_dir,
            recycle_num, 
            niter, 
            c_puct, 
            jumpout, 
            trust_radius=15,
        )

        training_pipeline.run(output_dir=output_dir)

        end_time = datetime.now()
        print(f"{init_num} output_dir: \n{output_dir}")
        print("Cost: {}s".format(end_time - start_time))
        currentDateAndTime = datetime.now()
        print("The current date and time is", currentDateAndTime)
        # Output: The current date and time is 2022-03-19 10:05:39.482383